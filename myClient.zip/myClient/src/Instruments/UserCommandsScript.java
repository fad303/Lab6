package Instruments;

import Classes.Status;
import Classes.Worker;
import Commands.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Vector;

public class UserCommandsScript extends UserCommands {

    public static void check (String userCommand) {       //Определяет status
        UserCommands.status = ProcessingScript.commands (userCommand.toLowerCase(), userCommand);
    }

    public static void execute(String userCommand, BufferedReader reader, Vector<Worker> workers, LocalDateTime today, ArrayList<String> history, ArrayList<String> scriptCommands, int i) throws IOException {      // Выполняет команду, если status == 1
        if (UserCommands.status == 1){
            if (userCommand.equalsIgnoreCase("help")) {
                Help help = new Help();
                help.execute();
                ScriptInfo.setInfo(help.getInfo());
            } else
            if (userCommand.equalsIgnoreCase("exit")) {
                ScriptInfo.setInfo("Сервер не поддерживает введённу команду");
            } else
            if (userCommand.equalsIgnoreCase("show")) {
                Show show = new Show(workers);
                show.execute();
                ScriptInfo.setInfo(show.getInfo());
            } else
            if (userCommand.equalsIgnoreCase("info")) {
                Info infoCom = new Info(workers, today);
                infoCom.execute();
                ScriptInfo.setInfo(infoCom.getInfo());
            } else
            if (userCommand.equalsIgnoreCase("add")) {
                ScriptAdd add = new ScriptAdd(workers, scriptCommands, i);
                if (add.fields() != 0) {
                    add.execute();
                    ScriptInfo.setInfo(add.getInfo());
                } else {
                    ScriptInfo.setInfo(add.getInfo());
                    ScriptInfo.setInfo("Ошибка создания элеммента коллекции");
                }
            } else
            if (userCommand.equalsIgnoreCase("clear")) {
                Clear clear = new Clear(workers);
                clear.execute();
                ScriptInfo.setInfo(clear.getInfo());
            } else
            if (userCommand.equalsIgnoreCase("save")) {
                ScriptInfo.setInfo("Сервер не поддерживает введённу команду");
            } else
            if (userCommand.equalsIgnoreCase("history")) {
                History his = new History(history);
                his.execute();
                ScriptInfo.setInfo(his.getInfo());
            }
            try {
                if (userCommand.substring(0, 6).equalsIgnoreCase("update")) {
                    String[] parts = userCommand.split(" ", 2);
                    Integer id = 0; int control = 1;
                    try {
                        id = Integer.parseInt(parts[1]);
                    }
                    catch (Exception e) {
                        control = 0;
                    }
                    if (control != 0) {
                        ScriptUpdate update = new ScriptUpdate(workers, id, scriptCommands, i);
                        if (update.fieldsUpdate() == 1) ScriptInfo.setInfo("Элемент обновлен");
                        else {
                            ScriptInfo.setInfo(update.getInfo());
                            ScriptInfo.setInfo("Сбой обновления элемента коллекции");
                        }
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 12).equalsIgnoreCase("remove_by_id")) {
                    String[] parts = userCommand.split(" ", 2);
                    Long id = 0L; int control = 1;
                    try {
                        id = Long.parseLong(parts[1]);
                    }
                    catch (Exception e) {
                    }
                    if (control != 0) {
                        Remove_By_Id rmi = new Remove_By_Id(workers, id);
                        rmi.execute();
                        ScriptInfo.setInfo(rmi.getInfo());
                    }
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 12).equalsIgnoreCase("remove_lower")) {
                    String[] parts = userCommand.split(" ", 2);
                    Long id = Long.parseLong(parts[1]);
                    Remove_lower rl = new Remove_lower(workers, id);
                    rl.execute();
                    ScriptInfo.setInfo(rl.getInfo());
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 16).equalsIgnoreCase("Filter_by_status")) {
                    String[] parts = userCommand.split(" ", 2);
                    Status status = Status.valueOf(parts[1]);
                    Filter_by_status fbs = new Filter_by_status(workers, status);
                    fbs.execute();
                }
            }
            catch (Exception e) {
            }
            try {
                if (userCommand.substring(0, 20).equalsIgnoreCase("filter_contains_name")) {
                    String[] parts = userCommand.split(" ", 2);
                    String containsName = parts[1].toString();
                    Filter_contains_name fcn = new Filter_contains_name(workers, containsName);
                    fcn.execute();
                    ScriptInfo.setInfo(fcn.getInfo());
                }
            }
            catch (Exception e) {
            }
        }
    }

    public static int getStatus () {
        return status;
    }
}
