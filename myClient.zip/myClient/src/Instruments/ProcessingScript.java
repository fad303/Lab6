package Instruments;

import Classes.Status;

import java.io.File;


public class ProcessingScript extends Processing {

    public static int commands (String userCommand, String OriginalUC) {
        if ((userCommand.length() == 6 && userCommand.equalsIgnoreCase("update")) ||
                (userCommand.length() == 7 && userCommand.equalsIgnoreCase("update "))) {
            ScriptInfo.setInfo("Для команды \"" + userCommand + "\" требуется указать id элемента коллекции. " +
                    "Для просмотра списка команд введите \"help\".");
            return 0;
        }
        else if ((userCommand.length() > 7 && userCommand.contains("update "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                ScriptInfo.setInfo("Для команды update требуется указать только id элемента коллекции. " +
                        "Для просмотра списка команд введите \"help\".");
                return 0;
            }
            else {
                try {
                    Long id = Long.parseLong((parts[1]));
                    if (id <= 0) {
                        ScriptInfo.setInfo("Id элемента коллекции должен быть целым положительным числом");
                        return 0;
                    }
                } catch (NumberFormatException e) {
                    ScriptInfo.setInfo("Id элемента коллекции должен быть целым положительным числом");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 12 && userCommand.equalsIgnoreCase("remove_by_id")) ||
                (userCommand.length() == 13 && userCommand.equalsIgnoreCase("remove_by_id "))) {
            ScriptInfo.setInfo("Для команды \"" + userCommand + "\" требуется указать id элемента коллекции. " +
                    "Для просмотра списка команд введите \"help\".");
            return 0;
        }

        else if ((userCommand.length() > 13 && userCommand.contains("remove_by_id "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                ScriptInfo.setInfo("Для команды \"remove_by_id\" требуется указать только id элемента коллекции. " +
                        "Для просмотра списка команд введите \"help\".");
                return 0;
            }
            else {
                try {
                    Long id = Long.parseLong((parts[1]));
                    if (id <= 0) {
                        ScriptInfo.setInfo("Id элемента коллекции должен быть целым положительным числом");
                        return 0;
                    }
                } catch (NumberFormatException e) {
                    ScriptInfo.setInfo("Id элемента коллекции должен быть целым положительным числом");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 14 && userCommand.equalsIgnoreCase("execute_script")) ||
                (userCommand.length() == 15 && userCommand.equalsIgnoreCase("execute_script "))) {
            ScriptInfo.setInfo("Для команды \"" + userCommand + "\" требуется указать имя файла. " +
                    "Для просмотра списка команд введите \"help\".");
            return 0;
        }

        else if ((userCommand.length() > 15 && userCommand.contains("execute_script "))) {
            String[] parts = OriginalUC.split(" ",3);
            if (parts.length != 2) {
                ScriptInfo.setInfo("Для команды execute_script требуется указать только имя файла. " +
                        "Для просмотра списка команд введите \"help\".");
                return 0;
            }
            else {
                File file = new File(parts[1]);
                if (! file.exists()) {
                    ScriptInfo.setInfo("Указанный файл не найден");
                    return 0;
                }
            }
        }
        else if ((userCommand.length() == 12 && userCommand.equalsIgnoreCase("remove_lower")) ||
                (userCommand.length() == 13 && userCommand.equalsIgnoreCase("remove_lower "))) {
            ScriptInfo.setInfo("Для команды \"" + userCommand + "\" требуется указать значение поля \"numberOfRooms\" элемента коллекции. " +
                    "Для просмотра списка команд введите \"help\".");
            return 0;
        }

        else if ((userCommand.length() > 13 && userCommand.contains("remove_lower "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                ScriptInfo.setInfo("Для команды \"remove_lower\" требуется указать только значение поля \"numberOfRooms\" элемента коллекции. " +
                        "Для просмотра списка команд введите \"help\".");
                return 0;
            }
            else {
                try {
                    Long id = Long.parseLong(parts[1]);
                    if (id<=0) { ScriptInfo.setInfo("Поле \"id\" должно быть положительным числом"); return 0; }
                }
                catch (Exception e) {
                    ScriptInfo.setInfo("Поле \"numberOfRooms\" должно быть числом");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 16 && userCommand.equalsIgnoreCase("filter_by_status")) ||
                (userCommand.length() == 17 && userCommand.equalsIgnoreCase("filter_by_status "))) {
            ScriptInfo.setInfo("Для команды \"" + userCommand + "\" требуется указать поле status. " +
                    "Для просмотра списка команд введите \"help\".");
            return 0;
        }

        else if ((userCommand.length() > 17 && userCommand.contains("filter_by_status "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                ScriptInfo.setInfo("Для команды \"filter_by_status\" требуется указать только поле status. " +
                        "Для просмотра списка команд введите \"help\".");
                return 0;
            }
            else {
                try {
                    Status status = Status.valueOf((parts[1]));
                    return 0;
                } catch (Exception e) {
                    ScriptInfo.setInfo("Значение status должно быть одним из списка:  HIRED,RECOMMENDED_FOR_PROMOTION,REGULAR,PROBATION;");
                    return 0;
                }
            }
        }

        else if ((userCommand.length() == 20 && userCommand.equalsIgnoreCase("filter_contains_name")) ||
                (userCommand.length() == 21 && userCommand.equalsIgnoreCase("filter_contains_name "))) {
            ScriptInfo.setInfo("Для команды \"" + userCommand + "\" требуется указать поле status. " +
                    "Для просмотра списка команд введите \"help\".");
            return 0;
        }

        else if ((userCommand.length() > 21 && userCommand.contains("filter_filter_contains_name "))) {
            String[] parts = userCommand.split(" ",3);
            if (parts.length != 2) {
                ScriptInfo.setInfo("Для команды \"filter_filter_contains_name\" требуется указать только одно name. " +
                        "Для просмотра списка команд введите \"help\".");
                return 0;
            }
            else {
                try {
                    String name = parts[1];
                    return 0;
                } catch (Exception e) {
                    ScriptInfo.setInfo("Необходимо ввести значение name");
                    return 0;
                }
            }
        }

        else {
            try {
                Commands command = Commands.valueOf(userCommand);
            }
            catch (IllegalArgumentException NullPointerException){
                ScriptInfo.setInfo("Система не поддерживает комманду \""+userCommand+"\". " + "Для просмотра списка команд введите \"help\".");
                return 0;
            }
        }
        return 1;
    }
}
