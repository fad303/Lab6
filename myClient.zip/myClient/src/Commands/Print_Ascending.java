package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.util.Vector;

public class Print_Ascending implements Serializable {
    private transient Vector<Worker> workers;
    private String info;

    public Print_Ascending(Vector<Worker> workers) {
        this.workers = workers;
    }

    public Print_Ascending() {}

    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers) {
        this.workers = workers;
    }

    static Vector <Worker> sortVector ( Vector<Worker> vector){
        for (int i =0; i < vector.size(); i++){
            for(int j = i + 1; j <= vector.size() - 1; j++){
                if (vector.get(i).getId() > vector.get(j).getId()){
                    Worker tmp = vector.get(j);
                    vector.set(j, vector.get(i));
                    vector.set(i, tmp);
                }
            }
        }
        return  vector;
    }

    public void execute() {
        info = "";
        sortVector(workers);
        workers.stream().forEach(s -> info = info + s + "\n");
    }

    public String toStrings() {
        return "print_ascending";
    }
}
