package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.util.Vector;

public class Remove_lower implements Serializable {
    private transient Vector<Worker> workers;
    private Long id;
    private String info;

    public Remove_lower() {
        this.info = null;
    }

    public Remove_lower(Vector<Worker> workers, Long id) {
        this.workers = workers;
        this.id = id;
    }

    public Remove_lower(Long id) {
        this.id = id;
    }

    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers) {
        this.workers = workers;
    }

    public void execute() {
        int control = workers.size();
        try {
            workers.stream().filter(f -> f.getId() < id).forEach(f -> workers.remove(f));
        } catch (Exception e) {
        }
        if (control == workers.size()) info = " 0 элементов удалено";
        else {
            info = "Количесвто удалённых элементов:" + (control - workers.size()) ;
        }
        workers = null;
    }

    public String toStrings() {
        return "remove_lower "+ id;
    }
}
