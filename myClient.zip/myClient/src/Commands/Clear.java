package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.util.Vector;

public class Clear implements Serializable {
    private transient Vector<Worker> workers;
    private String info;

    public Clear() { info=null; }

    public Clear (Vector<Worker> workers) {
        info = null;
        this.workers = workers;
    }

    public void execute() {
        workers.clear();
        info = "Все элементы коллекции удалены";
        workers = new Vector<>();
    }

    public String getInfo() {
        return info;
    }

    @Override
    public String toString() {
        return "clear";
    }
}
