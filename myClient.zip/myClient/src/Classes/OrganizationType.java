package Classes;

import java.io.Serializable;

public enum OrganizationType {
    PUBLIC,
    TRUST,
    PRIVATE_LIMITED_COMPANY,
    EMPTY;
}