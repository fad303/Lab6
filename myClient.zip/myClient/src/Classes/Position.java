package Classes;

import java.io.Serializable;

public enum Position implements Serializable {
    LABORER,
    DEVELOPER,
    LEAD_DEVELOPER,
    COOK,
    CLEANER;
}