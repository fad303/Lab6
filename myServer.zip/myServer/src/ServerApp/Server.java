package ServerApp;

import Classes.Worker;
import Commands.Exit;
import Commands.Save;
import Instruments.Processing;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Vector;

public class Server {

    static final Logger logger = LoggerFactory.getLogger(Server.class);
    private static ObjectInputStream in;
    private static ObjectOutputStream out;
    public static final int port = 4444;
    private static Vector<Worker> workers;
    private static File file;
    private static ArrayList<String> scripts, history;
    private static LocalDateTime today;

    public static void setHistory(String command) {
        if (history != null) {
            if (history.size() < 11) {
                String[] parts = command.split(" ");
                history.add(parts[0]);
            } else {
                history.remove(0);
                String[] parts = command.split(" ");
                history.add(parts[0]);
            }
        } else {
            history = new ArrayList<>();
            String[] parts = command.split(" ");
            history.add(parts[0]);
        }
    }

    public static Vector<Worker> getWorkers () {
        return workers;
    }

    public static ArrayList<String> getHistory () {
        return history;
    }

    public static ArrayList<String> getScripts () {
        return scripts;
    }

    public static File getFile () {
        return file;
    }

    public static void main(String[] args) {

        workers = new Vector<>();
        try {
            workers = Instruments.Reader.readFile(file);   // Заполняет коллекцию из файла
        } catch (FileNotFoundException e) {
            System.err.println("Файл не найден");
        }
        today = LocalDateTime.now();
        history = new ArrayList<>();
        scripts = new ArrayList<>();

        try {
            ServerSocket socket = new ServerSocket (port);
            logger.info("Server app запущено");
            User user = new User();
            user.start();
            while (true) {
                Socket client = socket.accept();
                logger.info("Соединение установлено с {}", client.getInetAddress().getHostName());
                handleRequest(client);
            }
        } catch (UnknownHostException ex) {
            System.err.println("Хост не определен");
        } catch (IOException ex) {
            System.err.println("Соединение разорвано "+ ex);
        }
    }

    /**
     * Обрабатывает запрос клиента
     * ProcessingRequest.getResult(...) возвращает объект в виде обработанной команды
     * @param client
     */

    public static void handleRequest (Socket client) {
        try {
            in = new ObjectInputStream(client.getInputStream());
            out = new ObjectOutputStream(client.getOutputStream());

            out.writeObject(ProcessingRequest.getResult(in.readObject(), workers, today, client.getInetAddress(), scripts));

            logger.info("Ответ отправлен");

            in.close();
            out.close();
            client.close();
        } catch (IOException e) {
            System.err.println("Соединение разорвано"+e);
        }
        catch (ClassNotFoundException e) {
            System.err.println("Ошибка чтения");
        }
    }

    public static void handleUserCommand (String userCommand, Vector<Worker> workers, File file, BufferedReader reader) {
        if (userCommand.equalsIgnoreCase("")) {}
        else if (userCommand.equalsIgnoreCase("exit")) {
            Save save = new Save(workers, file);
            Exit exit = new Exit(reader);
            save.execute();
            System.out.println("Работа Server завешрена");
            exit.execute();
        }
        else if (userCommand.equalsIgnoreCase("save")) {
            Save save = new Save(workers, file);
            save.execute();
        }
        else if (ProcessingUserRequest.result(userCommand, workers, today) == 0) {
            System.out.println("Введённая команда не поддерживается сервером");
        }
    }
}

class User extends Thread {

    @Override
    public void run() {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String userCommand = null;
        while (true) {
            try {
                userCommand = reader.readLine();
            } catch (IOException e) {
                System.err.println("Ошибка ввода");
            }
            Server.handleUserCommand(userCommand, Server.getWorkers(), Server.getFile(), reader);
        }
    }
}
