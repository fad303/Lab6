package ServerApp;

import Classes.Status;
import Classes.Worker;
import Commands.*;
import Instruments.ScriptInfo;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Vector;

public class ProcessingUserRequest {

    public static int result(String userCommand, Vector<Worker> workers, LocalDateTime today) {

        if (userCommand.equalsIgnoreCase("help")) {
            Help help = new Help();
            help.execute();
            System.out.println(help.getInfo());
            Server.setHistory(help.toString());
            return 1;
        }

        if (userCommand.equalsIgnoreCase("clear")) {
            Clear clear = new Clear(workers);
            clear.execute();
            System.out.println(clear.getInfo());
            Server.setHistory(clear.toString());
            return 1;
        }

        if (userCommand.equalsIgnoreCase("show")) {
            Show show = new Show(workers);
            show.execute();
            System.out.println(show.getInfo());
            Server.setHistory(show.toString());
            return 1;
        }

        if (userCommand.equalsIgnoreCase("info")) {
            Info info = new Info(workers, today);
            info.execute();
            System.out.println(info.getInfo());
            Server.setHistory(info.toString());
            return 1;
        }

        if (userCommand.equalsIgnoreCase("add")) {
            Add add = new Add(workers);
            try {
                add.fields();
            } catch (IOException e) {
                e.printStackTrace();
            }
            add.execute();
            System.out.println(add.getInfo());
            Server.setHistory(add.toStrings());
            return 1;
        }

        String[] parts = userCommand.split(" ",2);
        if (parts[0].equalsIgnoreCase("remove_by_id")) {
            try {
                long id = Long.parseLong(parts[1]);
                if (id<=0) {
                    System.out.println("Поле id не является положительным числом");
                    return 1;
                } else {
                    Remove_By_Id rm = new Remove_By_Id(workers, id);
                    rm.execute();
                    System.out.println(rm.getInfo());
                    Server.setHistory(rm.toStrings());
                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Поле id не является целым числом");
                return 1;
            }
        }

        if (parts[0].equalsIgnoreCase("update")) {
            try {
                Long id = Long.parseLong(parts[1]);
                if (id<=0) {
                    System.out.println("Поле id не является положительным числом");
                    return 1;
                } else {
                    Update update = new Update(workers, id);
                    update.check();
                    if (update.getInfo().equalsIgnoreCase("+")) {
                        update.fieldsUpdate();
                        update.setWorkers(workers);
                        update.execute();
                        System.out.println(update.getInfo());
                        Server.setHistory(update.toStrings());
                    } else {
                        System.out.println(update.getInfo());
                    }
                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Поле id не является целым числом");
                return 1;
            }
        }

        if (parts[0].equalsIgnoreCase("remove_lower")) {
            try {
                long id = Long.parseLong(parts[1]); int control = 1;
                if (id<=0) {
                    System.out.println("Ошибка: id должно быть положительным числом");
                    return 1;
                }
                if (control != 0) {
                    Remove_lower rl = new Remove_lower(workers, id);
                    rl.execute();
                    System.out.println(rl.getInfo());
                    Server.setHistory(rl.toStrings());
                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Ошибка: id должно быть целым числом");
                return 1;
            }
        }

        if (userCommand.equalsIgnoreCase("history")) {
            History his = new History(Server.getHistory());
            his.execute();
            System.out.println(his.getInfo());
            Server.setHistory(his.toStrings());
            return 1;
        }

        if (parts[0].equalsIgnoreCase("filter_by_status")) {
            try {
                Status status = Status.valueOf(parts[1].toUpperCase()); int control = 1;
                if (control != 0) {
                    Filter_by_status fbs = new Filter_by_status(workers, status);
                    fbs.execute();
                    System.out.println(fbs.getInfo());
                    Server.setHistory(fbs.toStrings());
                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Ошибка: status должно быть одним из следующих значений (HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION)");
                return 1;
            }
        }

        if (parts[0].equalsIgnoreCase("filter_contains_name")) {
            try {
                String containsName = parts[1]; int control = 1;
                if (control != 0) {
                    Filter_contains_name fcn = new Filter_contains_name(workers, containsName);
                    fcn.execute();
                    System.out.println(fcn.getInfo());
                    Server.setHistory(fcn.toStrings());
                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Ошибка ввода");
                return 1;
            }
        }

        if (userCommand.equalsIgnoreCase("print_ascending")) {
            Print_Ascending pr = new Print_Ascending(workers);
            pr.execute();
            System.out.println(pr.getInfo());
            Server.setHistory(pr.toString());
            return 1;
        }

        if (parts[0].equalsIgnoreCase("execute_script")) {
            try {
                Execute_Script es = new Execute_Script(parts[1], Server.getHistory());
                ArrayList<String> scripts = Server.getScripts();
                scripts.add(parts[1]);
                es.setScripts(scripts);
                es.getCommandsFromFile();
                ScriptInfo.setStartInfo("");
                es.setFields(workers, today);
                es.execute();
                System.out.println(es.getInfo());
                Server.setHistory(es.toString());
                scripts.clear();
            }catch(Exception e){
                System.out.println("При вводе данной команды необходимо указывать название файла.");
            }
            return 1;
        }

        return 0;
    }
}
