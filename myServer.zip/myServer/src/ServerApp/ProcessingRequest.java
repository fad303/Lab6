package ServerApp;

import Classes.Worker;
import Commands.*;
import Instruments.ScriptInfo;

import java.net.InetAddress;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Vector;

public class ProcessingRequest {
    private static Help help;
    private static Clear clear;
    private static Show show;
    private static Info info;
    private static Add add;
    private static Update update;
    private static Remove_By_Id rmi;
    private static Remove_lower rl;
    private static History his;
    private static Filter_by_status fbs;
    private static Filter_contains_name fcn;
    private static Print_Ascending pr;
    private static Execute_Script es;

    public static Object getResult(Object request, Vector<Worker> workers, LocalDateTime today, InetAddress address, ArrayList<String> scripts) {

        help = new Help();
        if (request.getClass()==help.getClass()) {
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + help.toString() + "\"");
            help.execute();
            return help;
        }
        help = null;

        clear = new Clear(workers);
        if (request.getClass()==clear.getClass()) {
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + clear.toString() + "\"");
            clear.execute();
            return clear;
        }
        clear = null;

        show = new Show(workers);
        if (request.getClass()==show.getClass()) {
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + show.toString() + "\"");
            show.execute();
            return show;
        }
        show = null;

        info = new Info(workers, today);
        if (request.getClass()==info.getClass()) {
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + info.toString() + "\"");
            info.execute();
            return info;
        }
        info = null;

        add = new Add();
        if (request.getClass()==add.getClass()) {
            add = (Add) request;
            add.setWorkers(workers);
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + add.toStrings() + "\"");
            add.execute();
            return add;
        }
        add = null;

        update = new Update();
        if (request.getClass()==update.getClass()) {
            update = (Update) request;
            update.setWorkers(workers);
            if (update.getName()==null) {
                Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + update.toStringsNoArguments() + "\"");
                update.check();
                return update;
            } else {
                Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + update.toStrings() + "\"");
                update.execute();
                return update;
            }

        }
        update = null;

        rmi = new Remove_By_Id();
        if (request.getClass()==rmi.getClass()) {
            rmi = (Remove_By_Id) request;
            rmi.setWorkers(workers);
            Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + rmi.toStrings() + "\"");
            rmi.execute();
            return rmi;
        }
        rmi = null;

        rl = new Remove_lower();
        if (request.getClass()==rl.getClass()) {
            rl = (Remove_lower) request;
            rl.setWorkers(workers);
            Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + rl.toStrings() + "\"");
            rl.execute();
            return rl;
        }
        rl = null;

        his = new History();
        if (request.getClass()==his.getClass()) {
            his = (History) request;
            Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + his.toStrings() + "\"");
            his.execute();
            return his;
        }
        his = null;

        fbs = new Filter_by_status();
        if (request.getClass()==fbs.getClass()) {
            fbs = (Filter_by_status) request;
            Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + fbs.toStrings() + "\"");
            fbs.setWorkers(workers);
            fbs.execute();
            return fbs;
        }
        fbs = null;

        fcn = new Filter_contains_name();
        if (request.getClass()==fcn.getClass()) {
            fcn = (Filter_contains_name) request;
            Server.logger.info("Получен запрос от " + address.getHostName() + ": \"" + fcn.toStrings() + "\"");
            fcn.setWorkers(workers);
            fcn.execute();
            return fcn;
        }
        fcn = null;

        pr = new Print_Ascending();
        if (request.getClass()==pr.getClass()) {
            pr = (Print_Ascending) request;
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + pr.toStrings() + "\"");
            pr.setWorkers(workers);
            pr.execute();
            return pr;
        }
        pr = null;

        es = new Execute_Script();
        if (request.getClass()==es.getClass()) {
            es = (Execute_Script) request;
            Server.logger.info("Получен запрос от "+address.getHostName()+": \"" + es.toStrings() + "\"");
            ScriptInfo.setStartInfo("");
            es.setFields(workers, today);
            es.execute();
            return es;
        }
        es = null;

        return null;
    }
}
