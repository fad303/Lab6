package Commands;

import Classes.Worker;

import java.io.Serializable;
import java.util.Vector;

public class Remove_By_Id implements Serializable {
    private transient Vector<Worker> workers;
    private Long id;
    private String info;

   public Remove_By_Id () {
       this.info = null;
   }

    public Remove_By_Id(Vector<Worker> workers, Long id) {
        this.workers = workers;
        this.id = id;
    }

    public Remove_By_Id(long id) {
        this.id = id;
    }

    public String getInfo() {
        return this.info;
    }

    public void setWorkers(Vector<Worker> workers) {
       this.workers = workers;
    }

    public void execute() {
       int control = workers.size();
       try {
           workers.stream().filter(f -> f.getId().toString().equalsIgnoreCase(id.toString())).limit(1).forEach(f -> workers.remove(f));
       } catch (Exception e) {
       }
       if (control == workers.size()) info = "Элемента с id = "+ id +" не существует в коллекции";
       else info = "Элемент успешно удален";
        workers = null;
       id = null;
    }

    public String toStrings() {
        return "remove_by_id " + id;
    }
}
