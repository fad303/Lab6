package Commands;

import Classes.Worker;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class Save implements Serializable {
    private Vector<Worker> workers;
    private File file;

    public Save(Vector<Worker> workers, File file){
        this.workers = workers;
        this.file = file;
    }

    public static String[] toXml(Worker wrk){
        String[] FieldsArray;
        FieldsArray = new String[18];
        for (int j = 0; j < FieldsArray.length; j++ ){
            FieldsArray[0] = "  "+"<Worker>";
            FieldsArray[1] = "      " +"<id>" + wrk.getId() + "</id>";
            FieldsArray[2] = "      " +"<name>" + wrk.getName() + "</name>";
            FieldsArray[3] = "      " +"<coordinates>";
            FieldsArray[4] = "        " +"<x>"  + wrk.coordinates.getX() + "</x>";
            FieldsArray[5] = "        " +"<y>" + wrk.coordinates.getY() + "</y>";
            FieldsArray[6] = "      " +"</coordinates>";
            FieldsArray[7] = "      " +"<creationDate>" + DateTimeFormatter.ofPattern("dd.MM.yy").format(wrk.getCreationDate()) + "</creationDate>";
            FieldsArray[8] = "      " +"<salary>" + wrk.getSalary() + "</salary>";
            FieldsArray[9] = "      " +"<endDate>" + DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss").format(wrk.getEndDate()) + "</endDate>";
            FieldsArray[10] = "      " +"<position>" + wrk.getPosition() + "</position>";
            FieldsArray[11] = "      " +"<status>" + wrk.getStatus() + "</status>";
            FieldsArray[12] = "      " +"<organization>";
            FieldsArray[13] = "        " +"<fullName>" + wrk.organization.getFullName() + "</fullName>";
            FieldsArray[14] = "        " +"<employeesCount>" + wrk.organization.getEmployeesCount() + "</employeesCount>";
            FieldsArray[15] = "        " +"<type>" + wrk.organization.getType() + "</type>";
            FieldsArray[16] = "      " +"</organization>";
            FieldsArray[17] = " " +"</Worker>";
        }
        return FieldsArray;
    }

    public void execute() {
        try {
            String fileOut = "savedWorkers.xml";
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File(fileOut)));
            bw.write("<Workers>\n");
            for (int i = 0; i < workers.size(); i++) {
                String[] ArrayF = toXml(workers.elementAt(i));
                for (int jj = 0; jj < ArrayF.length; jj++) {
                    bw.write(ArrayF[jj] + "\n");
                }
            }
            bw.write("</Workers>\n");
            bw.close();
            System.out.println("Коллекция успешно сохранена");
            }
        catch (IOException e) {
            System.out.println("Ошибка сохранения");
        }

    }
}
