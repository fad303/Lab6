package Instruments;

public enum Commands {
    help,
    info,
    show,
    add,
    update,
    save,
    remove_by_id,
    clear,
    execute_script,
    exit,
    remove_lower,
    history,
    filter_contains_name,
    filter_by_status,
    print_ascending
}
