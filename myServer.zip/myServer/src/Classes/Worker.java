package Classes;

import java.io.Serializable;

public class Worker implements Serializable {
    private Long id;
    private String name;
    public Coordinates coordinates;
    private java.time.LocalDate creationDate;
    private int salary;
    private java.time.LocalDateTime endDate;
    private Position position;
    private Status status;
    public Organization organization;

    public Worker(Long id, String  name, Coordinates coordinates, java.time.LocalDate creationDate, int salary, java.time.LocalDateTime endDate, Position position, Status status, Organization organization){
        this.id = id;
        this.name = name;
        this.coordinates = coordinates;
        this.creationDate = creationDate;
        this.salary = salary;
        this.endDate = endDate;
        this.position = position;
        this.status = status;
        this.organization = organization;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public java.time.LocalDate getCreationDate(){ return creationDate; }
    public Coordinates getCoordinates(){return coordinates;}
    public int getSalary(){ return salary; }
    public java.time.LocalDateTime getEndDate(){ return endDate; }
    public Position getPosition(){ return position; }
    public Status getStatus(){ return status; }
    public Organization getOrganization(){return organization;}

    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setCreationDate (java.time.LocalDate creationDate){ this.creationDate = creationDate; }
    public void setCoordinates(Coordinates coordinates){this.coordinates = coordinates;}
    public void setSalary(int salary){ this.salary = salary; }
    public void setEndDate(java.time.LocalDateTime endDate){ this.endDate = endDate; }
    public void setPosition(Position position){ this.position = position; }
    public void setStatus(Status status){ this.status = status; }
    public void setOrganization(Organization organization){this.organization = organization;}


    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append(" id = " + id + ";" );
        sb.append(" name = " + name + ";");
        sb.append(" coordinates = " + coordinates.toString() + ";");
        sb.append(" creationDate = " + creationDate + ";");
        sb.append(" salary = " + salary + ";");
        sb.append(" endDate = " + endDate + ";");
        sb.append(" position = " + position + ";");
        sb.append(" status = " + status + ";");
        sb.append(" organization: " + organization.toString() + ";");
        return  sb.toString();
    }

}