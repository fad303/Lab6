package Classes;

import java.io.Serializable;

public class Coordinates implements Serializable {
    private double x;
    private float y;

    public Coordinates(double x, float y){
        this.x=x;
        this.y = y;
    }

    public double getX () {
        return x;
    }
    public float getY () {
        return y;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        return sb.append("[").append(x).append(";").append(y).append("]").toString();
    }
}