package Classes;

import java.io.Serializable;

public class Organization implements Serializable {
    private String fullName;
    private long employeesCount;
    private OrganizationType type;

    public Organization(String fullName, long employeesCount, OrganizationType type){
        this.fullName = fullName;
        this.employeesCount = employeesCount;

        this.type = type;
    }

    public String getFullName(){ return fullName; }
    public long getEmployeesCount(){ return employeesCount; }
    public OrganizationType getType(){ return type; }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("fullName = " + fullName + ";");
        sb.append(" employeesCount = " + employeesCount + ";");
        if (type == OrganizationType.EMPTY) {
            sb.append(" type = " + "\"\"");
        }else{
            sb.append(" type = " + type);
        }
        return sb.toString();
    }
}