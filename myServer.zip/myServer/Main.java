
import Classes.*;

import java.io.*;
import java.net.InetAddress;
import java.net.SocketException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.net.DatagramSocket;
import java.net.DatagramPacket;


public class Main {
    private static String fileOut = "savedWorkers.xml";

    public static Vector<Worker> workers = new Vector<>();

    static ArrayList<String> arrayString = new ArrayList<>();

    static Vector <Worker> sortVector ( Vector<Worker> vector){
        for (int i =0; i < vector.size(); i++){
            for(int j = i + 1; j <= vector.size() - 1; j++){
                if (vector.get(i).getId() > vector.get(j).getId()){
                    Worker tmp = vector.get(j);
                    vector.set(j, vector.get(i));
                    vector.set(i, tmp);
                }
            }
        }
        return  vector;
    }

    /**
     * This method parse the row
     * @param Row row from file
     * @param Tag tag value
     * @return values enclosed in tags
     */
    public static String parse_row(String Row, String Tag){
        String tmp = Row.replaceAll("<"+Tag+">", "").trim();
        tmp = tmp.replaceAll("</"+Tag+">", "");
        return tmp;
    }

    /**
     * This method executes command
     * @param input checks for file existence
     * @return return flag values
     */
    public static boolean commander(String input) throws IOException {

        Scanner scanner2 = new Scanner(System.in);
        String cmd_line = scanner2.nextLine();
        String[] cmd_array = cmd_line.split(" ");
        input = cmd_array[0];

        LocalDate dateInit = LocalDate.now();

        String add_name = null;
        int add_salary = 0;
        LocalDateTime add_endDate = null;
        Double add_x;
        Float add_y;
        Coordinates add_coordinates = null;
        Position add_position = null;
        Status add_status = null;
        Organization add_organization = null;
        String add_fullName = null;
        long add_employeesCount = 0;
        OrganizationType add_type = null;
        Long add_id;
        LocalDate add_creationDate;
        boolean bln= true;
        boolean bln2 = true;

        System.out.println(input);
        switch (input) {
            case "help": {
                System.out.println("help : справка по доступным командам \n" +
                        "info : информация о коллекции \n" +
                        "show : все елементов коллекции \n" +
                        "add {element} : добавить новый элемент \n" +
                        "update id {element} : обновить значение элемента, заданного по id\n" +
                        "remove_by_id id : удалить элемент коллекции по id\n" +
                        "clear : очистить коллекцию\n" +
                        "save : сохранить коллекцию в файл\n" +
                        "execute_script file_name : исполнить скрипт из указанного файла\n" +
                        "exit : завершить программу\n" +
                        "insert_at index {element} : добавить новый элемент в заданную позицию\n" +
                        "remove_lower {element} : удалить из коллекции все элементы, меньшие, чем заданный id\n" +
                        "history : последние 11 команд\n" +
                        "filter_by_status status : элементы, значение поля status которых равно заданному\n" +
                        "filter_contains_name name : элементы, значение поля name которых содержит заданную подстроку\n" +
                        "print_ascending : элементы коллекции в порядке возрастания");
                break;
            }
            case "add": {
                switch (cmd_array.length) {
                    case 5: {
                        try {
                            add_name = cmd_array[1];
                            add_salary = Integer.parseInt(cmd_array[2]);
                            if(add_salary > 0) {
                                String dateTimeTmp = cmd_array[3] + " " + cmd_array[4];
                                add_endDate = LocalDateTime.parse(dateTimeTmp, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
                                bln2 = false;
                            }else{
                                System.out.println("Salary can not be less then 0");
                            }
                        }catch(Exception e){
                            System.out.println("Date or salary entered incorrectly. Please, try again");
                        }
                        break;
                    }
                    case 4:{
                        System.out.println("Values entered incorrectly. Please, try again (add {name} {salary} {dd.MM.yy} {hh:mm:ss}");
                        break;
                    }
                    case 3:{
                        try {
                            add_name = cmd_array[1];
                            add_salary = Integer.parseInt(cmd_array[2]);
                            if(add_salary > 0) {
                                add_endDate = null;
                                bln2 = false;
                            }else{
                                System.out.println("Salary can not be less then 0");
                            }
                        }catch(Exception e){
                            System.out.println("Name and salary entered incorrectly. Please, try again");
                        }
                        break;
                    }
                    case 2:
                    case 1: {
                        System.out.println("Name and salary can not be empty");
                        break;
                    }
                }

                if(bln2==false) {
                    while (bln) {
                        try {
                            System.out.println("Enter coordinate x: ");
                            add_x = Double.parseDouble(scanner2.nextLine());
                            while (bln) {
                                System.out.println("Enter coordinate y: ");
                                add_y = Float.parseFloat(scanner2.nextLine());
                                add_coordinates = new Coordinates(add_x, add_y);
                                if (add_y < 77) {
                                    bln = false;
                                } else {
                                    System.out.println("Maximum value of y: 77");
                                }
                            }
                        } catch (NumberFormatException nre) {
                            System.out.println("Please, enter number");
                        }
                    }
                    bln = true;
                    while (bln) {
                        try {
                            System.out.println("Enter position, \n" + "LABORER, DEVELOPER, LEAD_DEVELOPER, COOK, CLEANER");
                            add_position = Position.valueOf(scanner2.nextLine().toUpperCase().trim());
                            bln = false;
                        } catch (IllegalArgumentException e) {
                            System.out.println("Values entered incorrectly\n");
                        }
                    }
                    bln = true;
                    while (bln) {
                        try {
                            System.out.println("Enter status, \n" + "HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION");
                            add_status = Status.valueOf(scanner2.nextLine().toUpperCase().trim());
                            bln = false;
                        } catch (IllegalArgumentException e) {
                            System.out.println("Values entered incorrectly\n");
                        }
                    }
                    bln=true;

                    System.out.println("Enter Organization ");
                    while(bln) {
                        System.out.println("Enter full name");
                        add_fullName = scanner2.nextLine();
                        if(add_fullName.equals("") || add_fullName.equals(null)){
                            System.out.println("Organization name cannot be empty");
                        }else {
                            bln = false;
                        }
                    }

                    while (bln) {
                        try {
                            while (bln) {
                                System.out.println("Enter employeesCount");
                                add_employeesCount = Long.parseLong(scanner2.nextLine());
                                if (add_employeesCount > 0) {
                                    bln = false;
                                } else {
                                    System.out.println("Value cannot be less then 0");
                                }
                            }
                        } catch (NumberFormatException nfe) {
                            System.out.println("Please, enter the number");
                        }
                    }

                    bln = true;
                    while (bln) {
                        try {
                            System.out.println("Enter Organization Type, \n" + "PUBLIC, TRUST, PRIVATE_LIMITED_COMPANY ");
                            String typestr = scanner2.nextLine();
                            if (typestr == "" || typestr == null || typestr.isEmpty()){
                                typestr = "EMPTY";
                            }
                            add_type = OrganizationType.valueOf(typestr.toUpperCase().trim());
                            bln = false;
                        } catch (IllegalArgumentException e) {
                            System.out.println("Values entered incorrectly\n");
                        }
                    }
                    add_organization = new Organization(add_fullName, add_employeesCount, add_type);

                    long maxId = -1;
                    for (int i = 0; i < workers.size(); i++) {
                        if (workers.elementAt(i).getId() > maxId) {
                            maxId = workers.elementAt(i).getId();
                        }
                    }

                    add_id = maxId + 1;
                    System.out.println("id = " + add_id.toString());
                    add_creationDate = LocalDate.now();
                    workers.add(new Worker(add_id, add_name, add_coordinates, add_creationDate, add_salary, add_endDate, add_position, add_status, add_organization));
                }
                arrayString.add(input);
                break;
            }

            case "update": {
                boolean checkId = false;
                for (int j = 0; j < workers.size(); j++){
                    if(workers.elementAt(j).getId() == Long.parseLong(cmd_array[1])){
                        checkId = true;
                    }
                }
                if (workers.size()==0 || !checkId){
                    System.out.println("Element is not exist");
                }else {
                    try {
                        int i = Integer.parseInt(cmd_array[1]);

                        int indexW = -1;
                        for (int j = 0; j < workers.size(); j++) {
                            if (workers.elementAt(j).getId() == i) {
                                indexW = j;
                            }
                        }
                        if (indexW == -1) {
                            System.out.println("This id is not exist");
                        } else {

                            bln2 = true;
                            switch (cmd_array.length) {
                                case 6: {
                                    try {
                                        add_name = cmd_array[2];
                                        add_salary = Integer.parseInt(cmd_array[3]);

                                        String dateTimeTmp = cmd_array[4] + " " + cmd_array[5];
                                        add_endDate = LocalDateTime.parse(dateTimeTmp, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
                                        bln2 = false;
                                    } catch (Exception e) {
                                        System.out.println("Date or salary entered incorrectly. Please, try again");
                                    }
                                    break;
                                }
                                case 5: {
                                    System.out.println("Values entered incorrectly. Please, try again (update {id} {name} {salary} {dd.MM.yy} {hh:mm:ss}");
                                    break;
                                }
                                case 4: {
                                    try {
                                        add_name = cmd_array[2];
                                        add_salary = Integer.parseInt(cmd_array[3]);
                                        add_endDate = null;
                                        bln2 = false;
                                    } catch (Exception e) {
                                        System.out.println("Name and salary entered incorrectly. Please, try again");
                                    }
                                    break;
                                }
                                case 3:
                                case 2: {
                                    System.out.println("Name and salary is not entered");
                                    break;
                                }
                                case 1: {
                                    System.out.println("Pleas, enter id and other date");
                                    break;
                                }
                            }

                            bln = true;
                            if (!bln2) {
                                while (bln) {
                                    try {
                                        System.out.println("Enter coordinate x: ");
                                        add_x = Double.parseDouble(scanner2.nextLine());
                                        while (bln) {
                                            System.out.println("Enter coordinate y: ");
                                            add_y = Float.parseFloat(scanner2.nextLine());
                                            add_coordinates = new Coordinates(add_x, add_y);
                                            if (add_y < 77) {
                                                bln = false;
                                            } else {
                                                System.out.println("Maximum value of y: 77");
                                            }
                                        }
                                    } catch (NumberFormatException nre) {
                                        System.out.println("Please, enter number");
                                    }
                                }

                                bln = true;
                                while (bln) {
                                    try {
                                        System.out.println("Enter position, \n" + "LABORER, DEVELOPER, LEAD_DEVELOPER, COOK, CLEANER");
                                        add_position = Position.valueOf(scanner2.nextLine().toUpperCase().trim());
                                        bln = false;
                                    } catch (IllegalArgumentException e) {
                                        System.out.println("Values entered incorrectly\n");
                                    }
                                }
                                bln = true;
                                while (bln) {
                                    try {
                                        System.out.println("Enter status, \n" + "HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION");
                                        add_status = Status.valueOf(scanner2.nextLine().toUpperCase().trim());
                                        bln = false;
                                    } catch (IllegalArgumentException e) {
                                        System.out.println("Values entered incorrectly\n");
                                    }
                                }

                                bln = true;
                                System.out.println("Enter Organization ");
                                while(bln) {
                                    System.out.println("Enter full name");
                                    add_fullName = scanner2.nextLine();
                                    if(add_fullName.equals("") || add_fullName.equals("")){
                                        System.out.println("Organization name cannot be empty");
                                    }else {
                                        bln = false;
                                    }
                                }

                                while (bln) {
                                    try {
                                        System.out.println("Enter employeesCount");
                                        add_employeesCount = Long.parseLong(scanner2.nextLine());
                                        bln = false;
                                    } catch (NumberFormatException nfe) {
                                        System.out.println("Please, enter the number");
                                    }
                                }

                                bln = true;
                                while (bln) {
                                    try {
                                        System.out.println("Enter Organization Type, \n" + "PUBLIC, TRUST, PRIVATE_LIMITED_COMPANY ");
                                        String typestr = scanner2.nextLine();
                                        if (typestr.equals("") || typestr == null || typestr.isEmpty()) {
                                            typestr = "EMPTY";
                                        }
                                        add_type = OrganizationType.valueOf(typestr.toUpperCase().trim());
                                        bln = false;
                                    } catch (IllegalArgumentException e) {
                                        System.out.println("Values entered incorrectly\n");
                                    }
                                }
                                add_organization = new Organization(add_fullName, add_employeesCount, add_type);

                                add_creationDate = LocalDate.now();

                                workers.set(indexW, new Worker(Long.valueOf(i), add_name, add_coordinates, add_creationDate, add_salary, add_endDate, add_position, add_status, add_organization));

                                bln = true;
                                System.out.println("Элемент обновлён");
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("You do not enter the id");
                    }
                }
                arrayString.add(input);
                break;
            }

            case "history": {
                if (arrayString.size() < 11) {
                    System.out.println(arrayString.toString());
                } else {
                    System.out.println(arrayString.subList(arrayString.size() - 12, arrayString.size() - 1));
                }
                arrayString.add(input);
                break;
            }

            case "info": {
                System.out.println(workers.getClass());
                System.out.println("Количество элементов: " + workers.size());
                System.out.println(dateInit);
                arrayString.add(input);
                break;
            }

            case "show": {
                if(workers.size()==0){
                    System.out.println("Collection is empty");
                }else {
                    Enumeration enu = workers.elements();
                    while (enu.hasMoreElements()) {
                        System.out.println(enu.nextElement());
                    }
                }
                arrayString.add(input);
                break;
            }

            case "save": {
                BufferedWriter bw = new BufferedWriter(new FileWriter(new File(fileOut)));
                bw.write("<Workers>\n");
                for (int i = 0; i < workers.size(); i++) {
                    String[] ArrayF = toXml(workers.elementAt(i));
                    for (int jj = 0; jj < ArrayF.length; jj++) {
                        bw.write(ArrayF[jj] + "\n");
                    }
                }
                bw.write("</Workers>\n");
                bw.close();
                System.out.println("Collection is save");
                arrayString.add(input);
                break;
            }

            case "filter_by_status": {
                int count = 0;
                if(workers.size()==0){
                    System.out.println("Collection is empty");
                }else {
                    try {
                        for (int i = 0; i < workers.size(); i++) {
                            if (workers.elementAt(i).getStatus() == Status.valueOf(cmd_array[1].toUpperCase().trim())) {
                                System.out.println(workers.elementAt(i));
                                count++;
                            }
                        }
                        if (count == 0) {
                            System.out.println("No matches found");
                        }
                    } catch (Exception e) {
                        System.out.println("This status is not exist");
                    }
                }
                arrayString.add(input);
                break;
            }

            case "remove_by_id": {
                try {
                    boolean chekPoint = true;
                    for (int i = 0; i < workers.size(); i++) {
                        if (workers.elementAt(i).getId() == Integer.parseInt(cmd_array[1])) {
                            workers.removeElementAt(i);
                            chekPoint = false;
                            System.out.println("Элемент удалён");
                        }
                    }
                    if(chekPoint) {
                        System.out.println("Element is not exist");
                    }

                }catch(Exception e){
                    System.out.println("Id was not entered");
                }
                arrayString.add(input);
                break;
            }

            case "remove_lower": {
                if(workers.size()==0){
                    System.out.println("Collection is empty");
                }else {
                    try {
                        for (int i = 0; i < workers.size(); i++) {
                            if (Integer.parseInt(cmd_array[1]) == workers.elementAt(i).getId()) {
                                for (int j = 0; j < i; j++) {
                                    workers.removeElementAt(j);
                                }
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("Id was not entered");
                    }
                    System.out.println("All elements which id lower than" + cmd_array[1] + "is removed");
                }
                arrayString.add(input);
                break;
            }

            case "print_ascending": {
                if(workers.size()==0){
                    System.out.println("Collection is empty");
                }else {
                    sortVector(workers);
                    Enumeration enu = workers.elements();
                    while (enu.hasMoreElements()) {
                        System.out.println(enu.nextElement());
                    }
                }
                arrayString.add(input);
                break;
            }

            case "clear": {
                workers.removeAllElements();
                System.out.println("Все элементы удалены");
                arrayString.add(input);
                break;
            }

            case "filter_contains_name": {
                int count = 0;
                if(workers.size()==0){
                    System.out.println("Collection is empty");
                }else {
                    try {
                        for (int i = 0; i < workers.size(); i++) {
                            if (workers.elementAt(i).getName().contains(cmd_array[1])) {
                                System.out.println(workers.elementAt(i));
                                count++;
                            }
                        }
                        if (count ==  0){
                            System.out.println("No matches found");
                        }
                    } catch (Exception e) {
                        System.out.println("Name was not entered");
                    }
                }
                arrayString.add(input);
                break;
            }

            case "insert_at": {
                if(workers.size()==0){
                    System.out.println("Collection is empty");
                }else {
                    bln2 = true;
                    switch (cmd_array.length) {
                        case 6: {
                            try {
                                add_name = cmd_array[2];
                                add_salary = Integer.parseInt(cmd_array[3]);
                                if (add_salary > 0) {
                                    String dateTimeTmp = cmd_array[4] + " " + cmd_array[5];
                                    add_endDate = LocalDateTime.parse(dateTimeTmp, DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss"));
                                    bln2 = false;
                                } else {
                                    System.out.println("Salary can not be less then 0");
                                }

                            } catch (Exception e) {
                                System.out.println("Date entered incorrectly. Please, try again");
                            }
                            break;
                        }
                        case 5: {
                            System.out.println("Values entered incorrectly. Please, try again (insert_at {index} {name} {salary} {dd.MM.yy} {hh:mm:ss}");
                            break;
                        }
                        case 4: {
                            try {
                                add_name = cmd_array[2];
                                add_salary = Integer.parseInt(cmd_array[3]);
                                if (add_salary > 0) {
                                    add_endDate = null;
                                    bln2 = false;
                                } else {
                                    System.out.println("Salary can not be less then 0");
                                }
                            } catch (Exception e) {
                                System.out.println("Values entered incorrectly. Please, try again");
                            }
                            break;
                        }
                        case 3:
                        case 2: {
                            System.out.println("Name and salary do not enter ");
                            break;
                        }
                        case 1: {
                            System.out.println("Command entered incorrectly");
                        }
                    }

                    bln = true;
                    if (!bln2) {
                        while (bln) {
                            try {
                                System.out.println("Enter coordinate x: ");
                                add_x = Double.parseDouble(scanner2.nextLine());
                                while (bln) {
                                    System.out.println("Enter coordinate y: ");
                                    add_y = Float.parseFloat(scanner2.nextLine());
                                    add_coordinates = new Coordinates(add_x, add_y);
                                    if (add_y < 77) {
                                        bln = false;
                                    } else {
                                        System.out.println("Maximum value of y: 77");
                                    }
                                }
                            } catch (NumberFormatException nre) {
                                System.out.println("Please, enter number");
                            }
                        }

                        bln = true;
                        while (bln) {
                            try {
                                System.out.println("Enter position, \n" + "LABORER, DEVELOPER, LEAD_DEVELOPER, COOK, CLEANER");
                                add_position = Position.valueOf(scanner2.nextLine().toUpperCase().trim());
                                bln = false;
                            } catch (IllegalArgumentException e) {
                                System.out.println("Values entered incorrectly\n");
                            }
                        }
                        bln = true;
                        while (bln) {
                            try {
                                System.out.println("Enter status, \n" + "HIRED, RECOMMENDED_FOR_PROMOTION, REGULAR, PROBATION");
                                add_status = Status.valueOf(scanner2.nextLine().toUpperCase().trim());
                                bln = false;
                            } catch (IllegalArgumentException e) {
                                System.out.println("Values entered incorrectly\n");
                            }
                        }

                        bln = true;
                        System.out.println("Enter Organization ");
                        while(bln){
                            System.out.println("Enter full name");
                            add_fullName = scanner2.nextLine();
                            if (add_fullName.equals("") || add_fullName.equals(null)){
                                System.out.println("Organization name cannot be empty");
                            }else{
                                bln = false;
                            }
                        }


                        bln = true;
                        while (bln) {
                            try {
                                System.out.println("Enter employeesCount");
                                add_employeesCount = Long.parseLong(scanner2.nextLine());
                                bln = false;
                            } catch (NumberFormatException nfe) {
                                System.out.println("Please, enter the number");
                            }
                        }

                        bln = true;
                        while (bln) {
                            try {
                                System.out.println("Enter Organization Type, \n" + "PUBLIC, TRUST, PRIVATE_LIMITED_COMPANY ");
                                String typestr = scanner2.nextLine();
                                if (typestr == "" || typestr == null || typestr.isEmpty()) {
                                    typestr = "EMPTY";
                                }
                                add_type = OrganizationType.valueOf(typestr.toUpperCase().trim());
                                bln = false;
                            } catch (IllegalArgumentException e) {
                                System.out.println("Values entered incorrectly\n");
                            }
                        }
                        add_organization = new Organization(add_fullName, add_employeesCount, add_type);

                        long maxId = -1;
                        for (int i = 0; i < workers.size(); i++) {
                            if (workers.elementAt(i).getId() > maxId) {
                                maxId = workers.elementAt(i).getId();
                            }
                        }

                        if (workers.size() == 0) {
                            add_id = 1L;
                        } else {
                            add_id = maxId + 1;
                        }
                        System.out.println("id = " + add_id.toString());
                        add_creationDate = LocalDate.now();

                        workers.add(Integer.parseInt(cmd_array[1]), new Worker(add_id, add_name, add_coordinates, add_creationDate, add_salary, add_endDate, add_position, add_status, add_organization));
                    }
                }
                arrayString.add(input);
                break;
            }
            case "execute_script":{
                if(input.equals(cmd_array[1])){
                    System.out.println("File cannot read itself");
                    arrayString.add(input);
                }else {
                    try {
                        commander(cmd_array[1]);
                        arrayString.add(input);
                        break;
                    } catch (Exception e) {
                        System.out.println("Date in file entered incorrectly");
                    }
                }
            }
            default:{
                System.out.println("Incorrect command");
                break;
            }
        }
        return true;
    }

    /**
     * parse the file and add elements of collection
     * @param fileName File name
     */
    public  static boolean fileParser(String fileName){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yy");
        DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss");

         Long id = 0L;
         String name = "";
         String empty = "";
         Coordinates coordinates = new Coordinates(0, 0);
         Double x = 0.0;
         Float y = 0.0F;
         java.time.LocalDate creationDate = LocalDate.parse("01.01.20", formatter);
         int salary = 0;
         java.time.LocalDateTime endDate = LocalDateTime.parse("01.01.20 00:00:00", formatter2);
         Position position = null;
         Status status = null;
         Organization organization = new Organization("AAA", 0, OrganizationType.PUBLIC); //Organization
         String fullName = null;
         Long employeesCount = 0L;
         OrganizationType type = null;
         boolean chk = true;
         boolean bln = true;

        try (Scanner sc = new Scanner(new File(fileName))) {
            while (sc.hasNext()) {
                String holder0 = sc.nextLine();
                String tr0 = holder0.trim();
                if (tr0.startsWith("<Worker>")) {
                    String holder = sc.nextLine();
                    String tr = holder.trim();
                    while (!(tr.startsWith("</Worker>"))){

                    if (tr.startsWith("<id>")) {
                        id = Long.parseLong(parse_row(tr, "id"));
                        for (int i = 0; i < workers.size(); i++){
                            if (workers.elementAt(i).getId() == id){
                                System.out.println("Duplicate id found");
                                return chk = true;
                            }
                        }if(id < 0){
                            System.out.println("Id can not be less then 0");
                            return chk = true;
                        }
                    }
                    if (tr.startsWith("<name>")) {
                        name = parse_row(tr, "name");
                        if (name.equals(empty)){
                            System.out.println("Name can not be empty");
                            return chk = true;
                        }
                    }

                    if (tr.startsWith("<coordinate")) {
                        try {
                            x = Double.parseDouble(parse_row(sc.nextLine(), "x"));
                            while (bln) {
                                y = Float.parseFloat(parse_row(sc.nextLine(), "y"));
                                coordinates = new Coordinates(x, y);
                                if (y < 77) {
                                    bln = false;
                                } else {
                                    System.out.println("Maximum value of y: 77");
                                    return chk = true;
                                }
                            }
                        } catch (NumberFormatException nre) {
                            System.out.println("Coordinates must be a number");
                            return chk = true;
                        }
                    }
                    try {
                        if (tr.startsWith("<creationDate>")) {
                            creationDate = LocalDate.parse(parse_row(tr, "creationDate"), formatter);
                        }
                    }catch(Exception e){
                        System.out.println("Creation date entered incorrectly");
                        return chk = true;
                        }

                    if (tr.startsWith("<salary>")) {
                        try {
                            salary = Integer.parseInt(parse_row(tr, "salary"));
                            if (salary < 0){
                                System.out.println("Salary can not be less then 0");
                                return chk = true;
                            }
                        }catch(Exception e){
                            System.out.println("Salary must be a number");
                            return chk = true;
                        }
                    }
                    if (tr.startsWith("<endDate>")) {
                        try {
                            endDate = LocalDateTime.parse(parse_row(tr, "endDate"), formatter2);
                        }catch(Exception e){
                            System.out.println("Date entered incorrectly");
                            return chk = true;
                        }
                    }
                    if (tr.startsWith("<position>")) {
                        try {
                            position = Position.valueOf(parse_row(tr, "position").toUpperCase().trim());
                        }catch(Exception e){
                            System.out.println("Position is not exist");
                            return chk = true;
                        }
                    }
                    if (tr.startsWith("<status>")) {
                        try {
                            status = Status.valueOf(parse_row(tr, "status").toUpperCase().trim());
                        }catch(Exception e){
                            System.out.println("Status is not exist");
                            return chk = true;
                        }
                    }
                    if (tr.startsWith("<organization>")) {
                        try {
                            fullName = parse_row(sc.nextLine(), "fullName");
                            if(fullName==""){
                                System.out.println("Organization name cannot be empty");
                            }
                            employeesCount = Long.parseLong(parse_row(sc.nextLine(), "employeesCount"));
                            if(employeesCount>0) {
                                type = OrganizationType.valueOf(parse_row(sc.nextLine(), "type").toUpperCase().trim());
                            }else{
                                System.out.println("Employees count can not be less then 0");
                                return chk = true;
                            }
                        }catch(Exception e){
                            System.out.println("Coordinates entered incorrectly");
                            return chk = true;
                        }
                        organization = new Organization(fullName, employeesCount, type);
                    }
                        holder = sc.nextLine();
                        tr = holder.trim();
                }
                    workers.add(new Worker(id, name, coordinates, creationDate, salary, endDate, position, status, organization));
                }
            }
            chk = false;
        } catch (Exception e) {
            System.out.println("The File was not found. Please, enter file name again:");
        }
        return chk;
    }

    /**
     * place collection array of String
     * @param wrk element of collection
     * @return string array
     */
    public static String[] toXml(Worker wrk){
        String[] FieldsArray;
        FieldsArray = new String[17];
        for (int j = 0; j < FieldsArray.length; j++ ){
            FieldsArray[0] = "  "+"<Worker>";
            FieldsArray[1] = "      " +"<id>" + wrk.getId() + "</id>";
            FieldsArray[2] = "      " +"<name>" + wrk.getName() + "</name>";
            FieldsArray[3] = "      " +"<coordinates>";
            FieldsArray[4] = "        " +"<x>"  + wrk.getCoordinates().getX() + "</x>";
            FieldsArray[5] = "        " +"<y>" + wrk.getCoordinates().getY() + "</y>";
            FieldsArray[6] = "      " +"</coordinates>";
            FieldsArray[7] = "      " +"<creationDate>" + DateTimeFormatter.ofPattern("dd.MM.yy").format(wrk.getCreationDate()) + "</creationDate>";
            FieldsArray[8] = "      " +"<salary>" + wrk.getSalary() + "</salary>";
            FieldsArray[9] = "      " +"<eadDate>" + DateTimeFormatter.ofPattern("dd.MM.yy HH:mm:ss").format(wrk.getEndDate()) + "</endDate>";
            FieldsArray[10] = "      " +"<position>" + wrk.getPosition() + "</position>";
            FieldsArray[11] = "      " +"<status>" + wrk.getStatus() + "</status>";
            FieldsArray[12] = "      " +"<organization>";
            FieldsArray[13] = "        " +"<fullName>" + wrk.getOrganization().getFullName() + "</fullName>";
            FieldsArray[14] = "          " +"<employeesCount>" + wrk.getOrganization().getEmployeesCount() + "</employeesCount>";
            FieldsArray[15] = "        " +"<type>" + wrk.getOrganization().getType() + "</type>";
            FieldsArray[12] = "      " +"</organization>";
            FieldsArray[16] = " " +"</Worker>";
        }
        return FieldsArray;
    }


    public static void main(String[] args) throws IOException {

        sortVector(workers);
        boolean chk = true;

        //String fileName = args[0];

        String fileName = "xml1.xml";
        chk = fileParser(fileName);
        DatagramSocket socket = new DatagramSocket(4445);
        byte[]buf = new byte[256];
        boolean running = true;
        while(true){
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);

            InetAddress address = packet.getAddress();
            int port = packet.getPort();
            packet = new DatagramPacket(buf, buf.length, address, port);
            String received = new String(packet.getData(), 0, packet.getLength());
            System.out.println(received);

            commander(received.trim());
            if (received.equals("exit")) {
                running = false;
                continue;
            }
            socket.send(packet);
        }

        //System.out.println("Enter command ");

        //boolean flag = true;
        /*
        while(flag) {

            flag = commander("");

        }
        */
    }
}
